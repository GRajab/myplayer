declare module '*.css';
